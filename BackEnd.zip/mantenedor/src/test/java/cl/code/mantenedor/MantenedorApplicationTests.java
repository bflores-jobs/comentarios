package cl.code.mantenedor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MantenedorApplicationTests {

	@Test
	void contextLoads() {
	}

}
