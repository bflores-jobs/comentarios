package cl.code.mantenedor.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Comentario {

    @Id
    private String correo;
    @Column(nullable = false)
    private String region;
    @Column(nullable = false)
    private String comentario;

    public Comentario() {
    }

    public Comentario(String correo, String region, String comentario) {
        this.correo = correo;
        this.region = region;
        this.comentario = comentario;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public String getRegion() {
        return region;
    }

    public void setRegion(String region) {
        this.region = region;
    }

    public String getComentario() {
        return comentario;
    }

    public void setComentario(String comentario) {
        this.comentario = comentario;
    }
}
