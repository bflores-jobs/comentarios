package cl.code.mantenedor.controller;

import cl.code.mantenedor.entity.Comentario;
import cl.code.mantenedor.service.ComentarioService;
import jakarta.websocket.server.PathParam;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
//http://localhost:8080/api/comentarios
@RequestMapping("/api/comentarios")
@CrossOrigin(origins="http://localhost:4200")
public class ComentarioController {

    private final ComentarioService comentarioService;

    public ComentarioController(ComentarioService comentarioService) {
        this.comentarioService = comentarioService;
    }

    //http://localhost:8080/api/comentarios
    @PostMapping
    public Comentario save(@RequestBody Comentario comentario){
        return comentarioService.save(comentario);
    }

    //http://localhost:8080/api/comentarios
    @GetMapping
    public List<Comentario> findAll(){
        return comentarioService.findAll();
    }

    //http://localhost:8080/api/comentarios/id
    @GetMapping("/{id}")
    public Comentario findById(@PathVariable String id){
        return comentarioService.findById(id);
    }

    //http://localhost:8080/api/comentarios/id
    @DeleteMapping("/{id}")
    public void deleteById(@PathVariable String id){
        comentarioService.deleteById(id);
    }

    //http://localhost:8080/api/comentarios
    @PutMapping
    public Comentario updateComentario(@RequestBody Comentario comentario){
        Comentario comentarioDb = comentarioService.findById(comentario.getCorreo());
        comentarioDb.setRegion(comentario.getRegion());
        comentarioDb.setComentario(comentario.getComentario());
        return comentarioService.update(comentarioDb);
    }

}
