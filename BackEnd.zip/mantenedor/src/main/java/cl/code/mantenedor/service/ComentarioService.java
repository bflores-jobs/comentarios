package cl.code.mantenedor.service;

import cl.code.mantenedor.entity.Comentario;

import java.util.List;

public interface ComentarioService {
    Comentario save(Comentario comentario);
    List<Comentario> findAll();
    Comentario findById(String Id);
    void deleteById(String Id);
    Comentario update(Comentario comentario);
}
